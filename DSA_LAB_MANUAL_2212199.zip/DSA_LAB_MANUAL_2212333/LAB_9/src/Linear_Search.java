import java.util.Scanner;

public class Linear_Search {
    private int[] array;
    private int end,a;
    public Linear_Search(int size){
        array = new int[size];
        a=-1;
    }
    public void add(int data){
        if (end < array.length){
            a++;
            array[a] = data;
            end++;
        }
        else {
            System.out.println("Full Array");
        }
    }
    public void search(int item){
        if (end>0){
            boolean found = false;
            int count=0;
            for (int i=0; i<end;i++){
                if (array[i] == item)
                {
                    count++;
                    found = true;
                    System.out.println("Item found " + item + " at index "+ i);
                }
            }
            if (found == false){
                System.out.println("Item not found");
            }
            else {
                System.out.println("Occurred "+count+" times");
                int sum = item * count;
                System.out.println("Sum is: "+sum);
            }
        }
        else {
            System.out.println("Empty Array!");
        }
    }
    public void display(){
        if (end>0){
            for (int i=0; i<end;i++){
                System.out.println(array[i]);
            }
        }
        else {
            System.out.println("Empty Array!");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Length of Array:");
        int leng = sc.nextInt();
        Linear_Search a = new Linear_Search(leng);
        int v = 0;
        do {
            System.out.println("Choose Operation\n1)Add\n2)Search\n3)Display\n4)End");
            int n = sc.nextInt();
            switch (n) {
                case 1:
                    System.out.println("Enter Item:");
                    int val = sc.nextInt();
                    a.add(val);
                    break;
                case 2:
                    System.out.println("Enter Item to search:");
                    int s = sc.nextInt();
                    a.search(s);
                    break;
                case 3:
                    a.display();
                    break;
            }
            System.out.println("To go back to main menu press 1");
            v=sc.nextInt();
        }
        while(v==1);
        }
    }