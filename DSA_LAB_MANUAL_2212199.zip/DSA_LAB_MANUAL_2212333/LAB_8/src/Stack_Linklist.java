import java.util.Scanner;

public class Stack_Linklist {

    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node top = null;

    public void stack_ll() {
        int n, a, data;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("1)Push data\n2)Pop data\n3)Display\n4)Min Value\n5)Max Value\n6)Even Numbers\n7)Odd Numbers\n8)Peek Value\n9)Average\n10)Reverse Stack");
            System.out.println("Enter your choice:");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    System.out.println("Enter the data: ");
                    data = sc.nextInt();
                    Node new_node = new Node(data);
                    if(top==null){
                        top=new_node;
                    }
                    else{
                        new_node.next=top;
                        top=new_node;
                    }
                    break;
                case 2:
                    if(top==null){
                        System.out.println("Stack is empty");
                    }
                    else{
                        top=top.next;
                    }
                    break;
                case 3:
                    Node temp = top;
                    System.out.println("The stack is listed below: ");
                    while(temp!=null){
                        System.out.println(temp.data);
                        temp=temp.next;
                    }
                    break;
                case 4:
                    int min = top.data;
                    Node temp_mi = top.next;
                    while (temp_mi != null) {
                        if (temp_mi.data < min) {
                            min = temp_mi.data;
                        }
                        temp_mi = temp_mi.next;
                    }
                    System.out.println("Minimum vale is: "+min);
                    break;
                case 5:
                    int max = top.data;
                    Node temp_ma = top.next;
                    while (temp_ma != null) {
                        if (temp_ma.data > max) {
                            max = temp_ma.data;
                        }
                        temp_ma = temp_ma.next;
                    }
                    System.out.println("Maximum value is: "+max);
                    break;
                case 6:
                    Node temp_e = top;
                    System.out.println("Even numbers:");
                    while (temp_e != null) {
                        if (temp_e.data % 2 == 0) {
                            System.out.println(temp_e.data);
                        }
                        temp_e = temp_e.next;
                    }
                    break;
                case 7:
                    Node temp_o = top;
                    System.out.println("Odd numbers:");
                    while (temp_o != null) {
                        if (temp_o.data % 2 != 0) {
                            System.out.println(temp_o.data);
                        }
                        temp_o = temp_o.next;
                    }
                    break;
                case 8:
                    Node temp_p = top;
                    System.out.println("Value on top is " + temp_p.data);
                    break;
                case 9:
                    Node temp_avg = top;
                    float sum = 0;
                    int c = 0;
                    while (temp_avg != null) {
                        sum = sum + temp_avg.data;
                        c++;
                        temp_avg = temp_avg.next;
                    }
                    System.out.println("Average is: " + (sum / c));
                    break;
                case 10:
                    Node temp_rev = top;
                    Node prev = null;
                    Node nn;
                    while (temp_rev != null) {
                        nn = temp_rev.next;
                        temp_rev.next = prev;
                        prev = temp_rev;
                        temp_rev = nn;
                    }
                    top = prev;
                    Node reversed = top;
                    System.out.println("Reversed Stack:");
                    while (reversed != null) {
                        System.out.println(reversed.data);
                        reversed = reversed.next;
                    }
                    break;
            }
        System.out.println("To see main menu again press 1");
        a=sc.nextInt();
    }
        while(a==1);
}

    public static void main(String[] args) {
        Stack_Linklist s_ll = new Stack_Linklist();
        s_ll.stack_ll();
    }
}
