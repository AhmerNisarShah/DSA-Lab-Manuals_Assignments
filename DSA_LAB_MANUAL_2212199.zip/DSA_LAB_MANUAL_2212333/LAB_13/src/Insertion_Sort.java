import java.util.Scanner;

public class Insertion_Sort {
    public void insertion_sort(){
        int size , i , j , location , temp;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements");
        size = sc.nextInt();
        int[] array = new int[size];

        for(i=0;i<size;i++){
            System.out.println("Enter the element "+i);
            array[i]=sc.nextInt();
        }

        for(i=1;i<=(size-1);i++){
            temp=array[i];
            j=i-1;
            while(temp<array[j] && j>i-1){
                array[j+1]=array[j];
                j=j-1;
                array[j+1]=temp;
            }
            System.out.println("Sorted elements are listed below");
            for(i=0;i<size;i++){
                System.out.println(array[i]);
            }
        }
    }
    public static void main(String[] args) {
        Insertion_Sort i_s = new Insertion_Sort();
        i_s.insertion_sort();
    }
}
