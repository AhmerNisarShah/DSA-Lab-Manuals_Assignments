import java.util.Scanner;

public class Queue_ll {
    static class Node {
        int data;
        Node front;
        Node rear;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node front = null;
    Node rear = null;

    public void queue_linkedlist() {
        int n, a, data;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("1)Enqueue Data\n2)Dequeue Data\n3)Display\n4)Min Value\n5)Max Value\n6)Even Numbers\n7)Odd Numbers\n8)Peek Value\n9)Average\n10)Reverse Queue\n11)Search by Value");
            System.out.println("Enter your choice:");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    System.out.println("Enter data: ");
                    data = sc.nextInt();
                    Node new_node = new Node(data);
                    if (front == null) {
                        front = new_node;
                        rear = new_node;
                    }
                    else {
                        rear.next = new_node;
                        rear = new_node;
                    }
                    break;
                case 2:
                    if (front == null) {
                        System.out.println("Underflow");
                    } else {
                        front = front.next;
                    }
                    break;
                case 3:
                    Node temp = front;
                    System.out.println("Items are: ");
                    while (temp != null) {
                        System.out.println(temp.data);
                        temp = temp.next;
                    }
                    break;
                case 4:
                    int min = front.data;
                    Node temp_mi = front.next;
                    while (temp_mi != null) {
                        if (temp_mi.data < min) {
                            min = temp_mi.data;
                        }
                        temp_mi = temp_mi.next;
                    }
                    System.out.println("Minimum value: " + min);
                    break;
                case 5:
                    int max = front.data;
                    Node temp_ma = front.next;
                    while (temp_ma != null) {
                        if (temp_ma.data > max) {
                            max = temp_ma.data;
                        }
                        temp_ma = temp_ma.next;
                    }
                    System.out.println("Maximum value: " + max);
                    break;
                case 6:
                    System.out.println("Even numbers:");
                    Node temp_e = front;
                    while (temp_e != null) {
                        if (temp_e.data % 2 == 0) {
                            System.out.println(temp_e.data);
                        }
                        temp_e = temp_e.next;
                    }
                    break;
                case 7:
                    System.out.println("Odd numbers:");
                    Node temp_o = front;
                    while (temp_o != null) {
                        if (temp_o.data % 2 != 0) {
                            System.out.println(temp_o.data);
                        }
                        temp_o = temp_o.next;
                    }
                    break;
                case 8:
                    if (front == null) {
                        System.out.println("Queue is empty");
                    }
                    else {
                        System.out.println("Peek Value: " + front.data);
                    }
                    break;
                case 9:
                    int sum = 0;
                    int count = 0;
                    float avg;
                    Node temp_avg = front;
                    while (temp_avg != null) {
                        sum += temp_avg.data;
                        count++;
                        temp_avg = temp_avg.next;
                    }
                    avg = sum / count;
                    System.out.println("Average: " + avg);
                    break;
                case 10:
                    Node temp_rev = front;
                    Node prev = null;
                    Node nn;
                    while (temp_rev != null) {
                        nn = temp_rev.next;
                        temp_rev.next = prev;
                        prev = temp_rev;
                        temp_rev = nn;
                    }
                    front = prev;
                    System.out.println("Reversed Queue:");
                    Node reversed = front;
                    while (reversed != null) {
                        System.out.println(reversed.data);
                        reversed = reversed.next;
                    }
                    break;
                case 11:
                    System.out.println("Enter the value to search: ");
                    int search = sc.nextInt();
                    int position = 1;
                    Node temp_s_v = front;
                    while (temp_s_v != null) {
                        if (temp_s_v.data == search) {
                            System.out.println("Value found at position: " + position);
                        }
                        temp_s_v = temp_s_v.next;
                        position++;
                    }
                    System.out.println("Value not found");
                    break;
            }
            System.out.println("If you want to see main menu press 1");
            a = sc.nextInt();
        }
        while (a == 1);
    }

    public static void main(String[] args) {
        Queue_ll q_ll = new Queue_ll();
        q_ll.queue_linkedlist();
    }
}
