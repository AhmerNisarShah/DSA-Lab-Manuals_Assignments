import java.util.Scanner;

public class Queue_ay {
    int front = -1;
    int rear = -1;
    int[] array = new int[5];

    public void queue_array() {
        int n, a, data;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("1)Enqueue Data\n2)Dequeue Data\n3)Display\n4)Even Numbers\n5)Odd Numbers\n6)Average\n7)Max Value\n8)Min Value\n9)Peek Value\n10)Search by Value");
            System.out.println("Enter your choice:");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    if((rear==array.length-1)){
                        System.out.println("overflow");
                    }
                    else{
                        System.out.println("Enter the data: ");
                        data=sc.nextInt();
                        if(front==-1 && rear==-1){
                            front=0;
                            rear=0;
                            array[rear]=data;
                        }
                        else{
                            rear=rear+1;
                            array[rear]=data;
                        }
                    }
                    break;
                case 2:
                    if(front==-1 && rear==-1){
                        System.out.println("Underflow");
                    }
                    else{
                        front = front+1;
                    }
                    break;
                case 3:
                    System.out.println("Items are: ");
                    for(int i=front;i<=rear;i++){
                        System.out.println(array[i]);
                    }
                    break;
                case 4:
                    System.out.println("Even numbers:");
                    for (int i = front; i <= rear; i++) {
                        if (array[i] % 2 == 0) {
                            System.out.println(array[i]);
                        }
                    }
                    break;
                case 5:
                    System.out.println("Odd numbers:");
                    for (int i = front; i <= rear; i++) {
                        if (array[i] % 2 != 0) {
                            System.out.println(array[i]);
                        }
                    }
                    break;
                case 6:
                    int sum = 0;
                    float avg;
                    for (int i = front; i <= rear; i++) {
                        sum += array[i];
                    }
                    avg = (sum / (rear - front + 1));
                    System.out.println("Average value: " + avg);
                    break;
                case 7:
                    int max = array[front];
                    for (int i = front + 1; i <= rear; i++) {
                        if (array[i] > max) {
                            max = array[i];
                        }
                    }
                    System.out.println("Maximum value: " + max);
                    break;
                case 8:
                    int min = array[front];
                    for (int i = front + 1; i <= rear; i++) {
                        if (array[i] < min) {
                            min = array[i];
                        }
                    }
                    System.out.println("Minimum value: " + min);
                    break;
                case 9:
                    if (front == -1) {
                        System.out.println("Queue is empty hence NO Peek value found");
                    } else {
                        System.out.println("Peek Value: " + array[front]);
                    }
                    break;
                case 10:
                    System.out.println("Enter the value to search:");
                    int search = sc.nextInt();
                    boolean found = false;
                    for (int i = front; i <= rear; i++) {
                        if (array[i] == search) {
                            System.out.println("Value " + search + " found at position " + (i - front + 1));
                            found = true;
                            break;
                        }
                    }
                    if (found == false) {
                        System.out.println("Value " + search + " not found.");
                    }
                    break;
            }
            System.out.println("If you want to see main menu press 1");
            a=sc.nextInt();
        }
        while (a==1);
    }

    public static void main(String[] args) {
        Queue_ay q_ay = new Queue_ay();
            q_ay.queue_array();
    }
}
