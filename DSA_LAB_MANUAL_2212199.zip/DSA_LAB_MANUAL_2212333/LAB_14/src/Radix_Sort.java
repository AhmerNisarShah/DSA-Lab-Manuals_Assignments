import java.util.Scanner;

public class Radix_Sort {

    public void radix(int[] array,int size){
        int len= size-1;
        int[] count = new int[10];
        for (int exp =1; exp<=100;exp=exp*10) {
            for (int i = 0; i < count.length; i++) {
                count[i] = 0;
            }
            for (int i = 0; i < size; i++) {
                count[(array[i] / exp) % 10]++;
            }
            for (int i = 1; i < count.length; i++) {
                count[i] = count[i] + count[i - 1];
            }
            int[] output = new int[size];
            for (int i = len; i >= 0; i--) {
                output[count[(array[i] / exp) % 10] - 1] = array[i];
                count[(array[i] / exp) % 10]--;
            }
            array = output;
        }
        System.out.println("Sorted elements are");
        for(int i=0;i<size;i++){
            System.out.println(array[i]);
        }
    }
    public static void main(String[] args) {

        int size, i, j, location;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements");
        size = sc.nextInt();
        int[] array = new int[size];

        for (i = 0; i < size; i++) {
            System.out.println("Enter the element " + i);
            array[i] = sc.nextInt();
        }
        System.out.println("Unsorted Array is");
        for(j=0;j<size;j++){
            System.out.println(array[j]);
        }
        Radix_Sort r_s = new Radix_Sort();
        r_s.radix(array,size);
    }
}