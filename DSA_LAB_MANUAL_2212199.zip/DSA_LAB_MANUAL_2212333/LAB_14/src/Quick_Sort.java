import java.util.Scanner;
public class Quick_Sort{

    int partition(int[] array, int start, int end) {
        int pivot = array[end];
        int pindex = start;

        for (int i = start; i < (end - 1); i++) {
            if (array[i] <= pivot) {
                int temp = array[pindex];
                array[pindex] = array[i];
                array[i] = temp;
                pindex++;
            }
        }
        int temp = array[pindex];
        array[pindex] = array[end];
        array[end] = temp;
        return (pindex);
    }

    public void quick(int[] array, int start, int end) {
        if (start < end) {
            int par = partition(array, start, end);
            quick(array, start, par - 1);
            quick(array, par + 1, end);
        }
    }

    public static void main(String[] args) {

        int size, i, j, location;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements");
        size = sc.nextInt();
        int[] array = new int[size];

        for (i = 0; i < size; i++) {
            System.out.println("Enter the element " + i);
            array[i] = sc.nextInt();
        }
        System.out.println("Unsorted elements are");
        for(i=0;i<size;i++){
            System.out.println(array[i]);
        }

        Quick_Sort q_s = new Quick_Sort();
        q_s.quick(array,0,size-1);

        System.out.println("Sorted elements are");
        for(i=0;i<size;i++){
            System.out.println(array[i]);
        }
    }
}