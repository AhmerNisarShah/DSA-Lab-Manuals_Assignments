import java.util.Scanner;

public class Merge_Sort {
    void merge1(int[] array, int start, int mid , int end) {
        int l = mid - start + 1;
        int r = end - mid;
        int[] left_array = new int[l];
        int[] right_array = new int[r];

        for (int i = 0; i < l; ++i) {
            left_array[i] = array[start + i];
        }
        for (int j = 0; j < r; ++j) {
            right_array[j] = array[mid + 1 + j];
        }

        int i = 0, j = 0;
        int k = start;
        while (i < l && j < r) {
            if (left_array[i] <= right_array[j]) {
                array[k] = left_array[i];
                i++;
            }
            else {
                array[k] = right_array[j];
                j++;
            }
            k++;
        }

        while (i < l) {
            array[k] = left_array[i];
            i++;
            k++;
        }

        while (j < r) {
            array[k] = right_array[j];
            j++;
            k++;
        }
    }

    void merge_sort(int[] array, int start, int end) {
        if (start < end) {
            int mid = (start + end) / 2;
            merge_sort(array,start,mid);
            merge_sort(array,mid+1,end);
            merge1(array,start,mid,end);
        }
    }

    public static void main(String[] args) {
        int size , i , j;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of elements");
        size = sc.nextInt();
        int[] array = new int[size];

        for(i=0;i<size;i++){
            System.out.println("Enter the element "+i);
            array[i] = sc.nextInt();
        }

        System.out.println("Unsorted Array is");
        for(j=0;j<size;j++){
            System.out.println(array[j]);
        }

        Merge_Sort m_s = new Merge_Sort();
        m_s.merge_sort(array,0,size-1);

        System.out.println("Sorted Array is");
        for(j=0;j<size;j++){
            System.out.println(array[j]);
        }
    }
}