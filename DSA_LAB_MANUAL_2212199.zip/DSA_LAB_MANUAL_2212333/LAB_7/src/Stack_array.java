import java.util.Scanner;

public class Stack_array {
    int top = -1;
    int[] array =new int[5];

    public void stack_ay() {
        int n,a,data;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("1)Push Data\n2)Pop Data\n3)Display\n4)For max\n5)For min\n6)For average\n7)Even\n8)Odd\n9)Reverse\n10)Peek Value");
            System.out.println("Enter your choice:");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    if (top == (array.length - 1)) {
                        System.out.println("Overflow");}
                    else {
                        System.out.println("Enter the data: ");
                        data = sc.nextInt();
                        top = top + 1;
                        array[top] = data;
                    }
                    break;
                case 2:
                    if (top == -1) {
                        System.out.println("Underflow");}
                    else {
                        top = top - 1;
                        System.out.println("Item deleted");
                    }
                    break;
                case 3:
                    System.out.println("Items are: ");
                    for (int j = top; j >= 0; j--) {
                        System.out.println(array[j]);
                    }
                    break;
                case 4:
                    int max=array[0];
                    for(int i=1 ; i<array.length;i++){
                        if(max < array[i]){
                            max = array[i];
                        }
                    }
                    System.out.println("Maximum value in stack is "+ max);
                    break;
                case 5:
                    int min = array[0];
                    for (int i = 1; i < array.length; i++) {
                        if (min > array[i]) {
                            min = array[i];
                        }
                    }
                    System.out.println("Minimum value in stack is " + min);
                    break;
                case 6:
                    float sum = 0;
                    for (int i = 0; i < array.length; i++) {
                        sum = sum + array[i];
                    }
                    float avg = sum / array[top];
                    System.out.println("Average of stack is " + avg);
                    break;
                case 7:
                    System.out.println("Even Numbers");
                    for (int i=0; i<array.length;i++){
                        if(array[i] % 2 == 0){
                            System.out.println(array[i]);
                        }
                    }
                    break;
                case 8:
                    System.out.println("Odd Numbers");
                    for (int i=0; i<array.length;i++){
                        if(array[i] % 2 != 0){
                            System.out.println(array[i]);
                        }
                    }
                    break;
                case 9:
                    System.out.println("Reverse Array");
                    int r_array[] = new int[array.length];
                    int count=0;
                    for (int i=top; i>=0;i--){
                        r_array[count] = array[i];
                        count++;
                    }
                    array=r_array;
                    break;
                case 10:
                    int p = array[top];
                    System.out.println("Value at the top "+p);
                    break;
                }
            System.out.println("If you want to see main menu again press 1");
            a=sc.nextInt();
        }
        while(a==1);
    }

    public static void main(String[] args) {
        Stack_array ay = new Stack_array();
        ay.stack_ay();
    }
}