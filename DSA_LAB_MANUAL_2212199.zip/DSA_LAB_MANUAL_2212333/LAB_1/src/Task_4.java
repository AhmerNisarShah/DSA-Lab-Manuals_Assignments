public class Task_4 {
    int dup = 0;
    public void duplicate(int[] num){
        for(int i=0;i<num.length;i++){
            for(int j=0;j<num.length;j++){
                if(i == j){
                    continue;
                }
                else{
                    if(num[i] == num[j]){
                        dup = dup + 1;
                        System.out.println("Duplication on " + i + " index and " + j + " index");
                    }
                }
            }
        }
    }
    public static void main(String[] args) {
        Task_4 t_4 = new Task_4();
        int[] array = {10001,10002,10003,10001};
        t_4.duplicate(array);
    }
}
