import java.util.Scanner;

public class Task_1 {
    public void value_42(int value){
        if(value == 42){
            System.out.println("Equal to 42");
        }
        else{
            System.out.println("Not Equal to 42");
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int num = sc.nextInt();
        Task_1 t_1 = new Task_1();
        t_1.value_42(num);
    }
}

