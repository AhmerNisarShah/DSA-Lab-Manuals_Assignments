public class Task_3 {
    public void sum(int[] num){
        int total = 0;
        for (int i=0;i<num.length;i++){
            total = total + num[i];
        }
        System.out.println("Total of the array is: "+total);
    }
    public static void main(String[] args) {
        Task_3 t_3 = new Task_3();
        int[] array = {1001,1002,1003,1004};
        t_3.sum(array);
    }
}
