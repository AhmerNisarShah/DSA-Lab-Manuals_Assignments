import java.util.Scanner;

public class Queue_cir {
    int front = -1;
    int rear = -1;
    int num = 5;
    int[] array = new int[num];

    public void queue_arraycir() {
        int n, a, data,i;
        do {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter 1 to enqueue the data\nEnter 2 to dequeue the data\nEnter 3 to Display");
            System.out.println("Enter your choice:");
            n = sc.nextInt();
            switch (n) {
                case 1:
                    if(front==(rear+1)%num){
                        System.out.println("Overflow");
                    }
                    else{
                        System.out.println("Enter data: ");
                        data=sc.nextInt();
                        if(front==-1 && rear==-1){
                            front=0;
                            rear=0;
                            array[rear]=data;
                        }
                        else{
                            rear=((rear+1)%num);
                            array[rear]=data;
                        }
                    }
                    break;
                case 2:
                    if(front==-1 && rear==-1){
                        System.out.println("Underflow");
                    }
                    else if(front==rear){
                        System.out.println("Underflow");
                        front=-1;
                        rear=-1;
                    }
                    else{
                        front = ((front+1)%num);
                    }
                    break;
                case 3:
                    System.out.println("Items are:");
                    for(i=front;i!=rear;i=((i+1)%num)){
                        System.out.println(array[i]);
                    }
                    System.out.println(array[i]);
                    break;
            }
            System.out.println("If you want to enqueue , dequeue , or display the queue press 1");
            a=sc.nextInt();
        }
        while (a==1);
    }

    public static void main(String[] args) {
        Queue_cir q_cir = new Queue_cir();
        q_cir.queue_arraycir();
    }

}
